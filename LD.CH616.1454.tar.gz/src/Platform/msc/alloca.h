#pragma once

#ifndef __cplusplus
#define alloca(size) _alloca(size)
#endif
