#pragma once

#if !defined(__cplusplus)

typedef int bool;
#define true 1
#define false 0

#endif
