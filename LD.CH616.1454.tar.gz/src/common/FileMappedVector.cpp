#include "FileMappedVector.h"

namespace {
char suppressMSVCWarningLNK4221;
}
