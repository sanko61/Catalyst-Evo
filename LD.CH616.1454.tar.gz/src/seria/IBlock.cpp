#include "IBlock.h"

namespace CryptoNote {
IBlock::~IBlock() {
}
}
